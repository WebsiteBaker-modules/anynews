/**
 * Code snippet: anynews
 *
 * This code snippets grabs news from the WB news module database
 * and displays them on any page you want by invoking the function
 * displayNewsItems() via a page of type code or the index.php 
 * file of the template.
 *
 * User defined JavaScript settings for the thirdparty jQuery plugin coda-slider-2.
 * Detailed information about the jQuery flexslider plugin and it's settings can
 * be found on website of the authors: http://www.ndoherty.biz/demos/coda-slider/2.0/
 * 
 * LICENSE: GNU General Public License 3.0
 * 
 * @platform    CMS Websitebaker 2.8.x
 * @package     anynews
 * @author      cwsoft (http://cwsoft.de)
 * @version     2.1.0
 * @copyright   cwsoft
 * @license     http://www.gnu.org/licenses/gpl.html
*/

$(document).ready(function() {
	// add your custom coda-slider-2 settings below
    $('#coda-slider-effect').codaSlider({
		autoHeight: false,
		autoHeightEaseDuration: 1000,
		autoHeightEaseFunction: 'easeInOut',
		
		autoSlide: true,
		autoSlideIntervall: 6000,
		autoSlideStopWhenClicked: true,
		
		crossLinking: true,
		
		dynamicArrows: true,
		dynamicArrowLeftText: '&#171',
		dynamicArrowRightText: '&#187',
		
		dynamicTabs: true,
		dynamicTabsAlign: 'center',
		dynamicTabsPosition: 'top',
		
		externalTriggerSelector: 'a.xtrig',
		firstPanelToLoad: 1,
		panelTitleSelector: 'span.panel-caption',
		slideEaseDuration: 1000,
		slideEaseFunction: 'easeInOutExpo'
	});
});